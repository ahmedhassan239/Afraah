<?php $__env->startSection('content'); ?>




    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 ">
                <div class="card mt-4 ">
                    <div class="card-body text-center ">
                        <div>
                            <h3 class="mt-3 mb-3"> Afraah </h3>
                            <svg class="block mx-auto mb-5" xmlns="http://www.w3.org/2000/svg" width="100" height="2" viewBox="0 0 100 2">
                                <path fill="#D8E3EC" d="M0 0h100v2H0z"></path>
                            </svg>
                        </div>


                        <form method="post" class="col-md-8 m-auto text-left " action="<?php echo e(route('user-regist')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="name"><?php echo e(__('English Name')); ?></label>
                                    <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div> <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="name"><?php echo e(__('Arabic Name')); ?></label>
                                    <input id="arabic_name" type="text" class="form-control <?php $__errorArgs = ['arabic_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="arabic_name" value="<?php echo e(old('arabic_name')); ?>" required autocomplete="name" autofocus>

                                    <?php $__errorArgs = ['arabic_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-12 register-form">
                                    <label for="email" ><?php echo e(__('E-Mail Address')); ?></label>

                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="phone" ><?php echo e(__('Phone Number')); ?></label>

                                    <input id="phone" type="number" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required autocomplete="phone">

                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="country"><?php echo e(__('Country')); ?></label>

                                    <select class="form-control country" name="country" id="country" data-dependent="city">
                                        <option disabled selected>Select Country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="city"><?php echo e(__('City')); ?></label>
                                    <div id="city">
                                        <select id="cities" name="city"class="cityname form-control">
                                            <option value="" disabled selected>Select City</option>
                                        </select>

                                    </div>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="country"><?php echo e(__('Category')); ?></label>

                                    <select class="form-control category" name="category" id="category" data-dependent="service">
                                        <option disabled selected>Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>



                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="service"><?php echo e(__('Service')); ?></label>
                                    <div id="service">
                                        <select id="services" name="service"class="servicename form-control">
                                            <option value="" disabled selected>Select Service</option>
                                        </select>

                                    </div>
                                    <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 register-form">
                                    <label for="gender"><?php echo e(__('Gender')); ?></label>
                                    <div id="gender">
                                        <select id="gender" name="gender" class="gendername form-control">
                                            <option value="" disabled selected>Select Your Gender</option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <?php echo e(csrf_field()); ?>



                            <div class="form-group row">

                                <div class="col-sm-12 register-form">
                                    <label for="password"  ><?php echo e(__('Password')); ?></label>

                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-12 register-form">
                                    <label for="password-confirm"  ><?php echo e(__('Confirm Password')); ?></label>

                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-12 mt-4 mb-5  ">
                                    <button type="submit" class="btn btn-register" >
                                        <?php echo e(__('Register')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type=text/javascript>
        $(document).ready(function(){
            $('.country').on('change',function(){
                $('#cities').html('');
                var country_id=$(this).val();
                var div =$(this).parent();
                //  console.log(country_id);
                var city = document.getElementById('cities')
                // console.log(city);
                var op=" ";
                $.ajax({
                    type:'get',
                    url:"<?php echo e(route('findCityName')); ?>",
                    data:{id:country_id},
                    success:function(data){
                        // console.log('success');
                        console.log(data);
                        op+='<option value="0" selected disabled>Select City</option>';
                        for(var i=0;i<data.length;i++){
                            op+=`<option class="form-control" value="${data[i].id}">${data[i].name}</option>`;
                            // console.log(data[i].id);
                        }
                        $('.cityname').append(op);
                    },
                    error:function(){
                    }
                });
            });
        });
    </script>
    <script type=text/javascript>
        $(document).ready(function(){
            $('.category').on('change',function(){
                $('#services').html('');
                var category_id=$(this).val();
                var div =$(this).parent();
                //  console.log(country_id);
                var service = document.getElementById('services')
                // console.log(city);
                var op=" ";
                $.ajax({
                    type:'get',
                    url:"<?php echo e(route('findServiceName')); ?>",
                    data:{id:category_id},
                    success:function(data){
                        // console.log('success');
                        console.log(data);
                        op+='<option value="0" selected disabled>Select Service</option>';
                        for(var i=0;i<data.length;i++){
                            op+=`<option class="form-control" value="${data[i].id}">${data[i].name}</option>`;
                            // console.log(data[i].id);
                        }
                        $('.servicename').append(op);
                    },
                    error:function(){
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\madonna\newtest\resources\views/auth/register.blade.php ENDPATH**/ ?>