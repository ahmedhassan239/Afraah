<?php
    $resources = collect(Nova::availableResources(request()));
    $navigation = $resources->filter(function($resource, $key) {
        return isset($resource::$subGroup);
    })->groupBy(function ($item, $key) {
        return $item::group();
    })->sortKeys()->all();

    $resourceGroupMenu = collect(Nova::availableTools(request()))->first(function($tool) {
        return $tool instanceof SaintSystems\Nova\ResourceGroupMenu\ResourceGroupMenu;
    });
?>
<?php if(count($navigation)): ?>
    <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $resources): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <router-link tag="a" :to="{ name: 'resource-group-menu', params: { 'group': '<?php echo e(\Illuminate\Support\Str::slug($group)); ?>' }}" class="cursor-pointer flex items-center font-normal dim text-white mb-6 text-base no-underline">
        

            
            <?php echo $resourceGroupMenu->getGroupIcon(\Illuminate\Support\Str::slug($group)); ?>

            <span class="sidebar-label">
                <?php echo e($group); ?>

            </span>

    </router-link>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php /**PATH E:\madonna\newtest\vendor\saintsystems\nova-resource-group-menu\src/../resources/views/navigation.blade.php ENDPATH**/ ?>