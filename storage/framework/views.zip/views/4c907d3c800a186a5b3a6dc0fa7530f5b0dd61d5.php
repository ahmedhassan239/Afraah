<div class="mx-auto py-8 max-w-sm text-center text-90">

</div>
<?php /**PATH E:\madonna\newtest\nova\src/../resources/views/auth/partials/header.blade.php ENDPATH**/ ?>